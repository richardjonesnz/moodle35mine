Modified
========
This is modified from Moodle HQ's moodle-mod_newmodule and Justin Hunt's Pairwork activity module for Moodle.  

This is hopefully a good basis for a simple lesson module that has basic features as follows:

1.  Supports adding questions from the question bank
2.  Consists of multimedia pages with simple hyperlinked navigation
3.  Summary lesson attempt reports for students and teacher's

For more complex needs (timing, access restrictions, use the Lesson activity module)
For summative activities use the quiz or lesson.

The current BETA version works in most respects with the remaining challenges:

    Backup and restore don't backup the page contents - an export model like that of mod_glossary will be developed.
    There is reporting but no grading just yet.

These are being worked on.

Optional features being considered (please consider making a request, especially if you are a teacher)

    Click to open panel, perhaps for additional hints and tips for the page resource
    Comments per page

Richard Jones
richardnz@outlook.com
